const o={GroupName:"组名","Group name":"组别名称",jurisdiction:"权限"};export{o as default};
