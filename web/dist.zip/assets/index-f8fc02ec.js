import{a5 as f}from"./index-97b412df.js";const n=(i,e,r)=>["gif","jpg","jpeg","bmp","png","webp"].includes(r)?i.full_url:f(r);export{n as p};
